export const DEFAULT_SIZE = 128000;

export const THEME = {
  Light: "light",
  Dark: "dark",
};

export const ROUTER = {
  Pages: "pages",
  App: "app",
};
