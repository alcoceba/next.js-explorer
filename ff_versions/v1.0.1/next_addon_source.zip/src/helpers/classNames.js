export const classNames = (...args) => args.filter((f) => f).join(" ");
