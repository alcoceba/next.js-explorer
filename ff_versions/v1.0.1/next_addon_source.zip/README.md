# Next.js Explorer extension

## Build Environment

This is the build enviroment packaged extension was generated:

- Manjaro Linux 24.0.5 Wynsdey
- Node 20.16.0 and npm 10.8.1

## Building the Extension

To build the extension:

1. Navigate to the extension directory
2. Run `npm install`
1. Run `npm run build:firefox`
2. The packaged extension will be available in the `dist_firefox` folder
